package finesseprototype;


import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import utils.MyFileUtil;
import utils.Properties;
import java.io.File;
import java.io.IOException;
import java.util.List;


import static utils.MyFileUtil.getFiles;

/**
 * ClassName Main
 * Description
 * Author Ymkal
 * Date  11/29/2020
 *
 *
 * 1.每次运行之后， 可以运行clear 函数，删除数据内容，压缩之后的文件夹是的配置为PROTOTYPE_RESULT_DIR, 在utils包下的Properties类中设置
 *  meta ： 元数据和上述一致
 *
 *  所有原型已用PROTOTYPE标明
 *
 */
public class Main {
    public static void main(String[] args) throws IOException {
        // 初始化
        Logger logger = Logger.getLogger(Main.class); // Log
        PropertyConfigurator.configure("log4j2.xml");
        BasicConfigurator.configure();
        // 配置文件夹
        try {
            String prefix = args[2];
            Properties.Reset(prefix);
        }catch (Exception e){
            logger.warn("没有配置文件夹前缀，默认为jar路径下的result_*文件夹");
        }
        //clear(); // 清楚上次运行产生的所有数据内容
        File folder_f = new File(args[0]);
        Finesse f = null;
        try {
            f = Finesse.getInstance();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 配置参数
        List<String> files = getFiles(folder_f);
        Finesse.setAverage_size(Integer.parseInt(args[1])); // 平均大小
        Finesse.setSub_chunk_count(12); // 每个块有多少个子块
        Finesse.setSfs_count(3); // 最终得到SF的个数

        long start = System.currentTimeMillis();
        logger.info("========================= Start Prototype Process =========================");
        for (String file : files) {
            f.Init(file);
            f.process();
        }
        logger.info("========================== End Prototype Process ==========================");
        long end = System.currentTimeMillis();
        logger.info("===========================================================================");
        logger.info(String.format("========Process time :  %s", end - start));
        long before_size = MyFileUtil.getFileSize(folder_f);
        long after_size = MyFileUtil.getFileSize(new File(Properties.PROTOTYPE_RESULT_DIR));
        logger.info(String.format("========DCR  :  %s", before_size * (1.0) / after_size));
        logger.info(String.format("========DCE  :  %s", Finesse.getDCE()));
        long metadata_size = MyFileUtil.getFileSize(new File(Properties.PROTOTYPE_METADATA_DIR));
        logger.info(String.format("========Meta size  :  %s", metadata_size));
        logger.info(String.format("========DCR2  :  %s", before_size * (1.0) / (after_size + metadata_size)));
        logger.info("==========================================================================");
        Finesse.close();
    }
    public static void clear(){
        File f1 = new File(Properties.PROTOTYPE_SF_PATH);
        f1.deleteOnExit();
        deleteFile(new File(Properties.PROTOTYPE_RESULT_DIR));
        deleteFile(new File(Properties.PROTOTYPE_METADATA_DIR));
    }

    public static void deleteFile(File dirFile) {
        // 如果dir对应的文件不存在，则退出
        if (!dirFile.exists()) {
            return ;
        }

        if (dirFile.isFile()) {
            dirFile.delete();
        } else {
            for (File file : dirFile.listFiles()) {
                deleteFile(file);
            }
        }
    }
}
