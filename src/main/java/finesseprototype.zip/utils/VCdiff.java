package utils;

import net.dongliu.vcdiff.VcdiffEncoder;
import net.dongliu.vcdiff.exception.VcdiffDecodeException;
import net.dongliu.vcdiff.exception.VcdiffEncodeException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * ClassName VCdiff
 * Description
 * Author Ka1HuangZhe
 * Date  10/17/2020
 */
public class VCdiff {
    /**
     * use vcdiff get the diff file length
     * @param dictionary resource file
     * @param uncompressedData target file
     * @return diff length (target file length - diff file length)
     */
    public static int get_diff_length(byte[] dictionary, byte[] uncompressedData) throws IOException, VcdiffEncodeException, VcdiffDecodeException {
        File resource = new File("resource.txt");
        OutputStream os = new FileOutputStream(resource);
        os.write(dictionary);
        os.flush();

        File targetFile = new File("target.txt");
        OutputStream os2 = new FileOutputStream(targetFile);
        os2.write(uncompressedData);
        os2.flush();

        File diffFile = new File("diff.txt");
        VcdiffEncoder.encode(resource,targetFile,diffFile);
        int result =  (uncompressedData.length - diffFile.length()) > 0 ? (int) diffFile.length() :uncompressedData.length;
        return result;
    }

    private static void removeFile(File f){
        if(f.delete()){
        }
    }
}
