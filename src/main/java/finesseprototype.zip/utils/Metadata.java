package utils;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * ClassName Matadata
 * Description
 * Author Ka1HuangZhe
 * Date  10/23/2020
 */
public class Metadata {
    private String file_name;
    private LocalDate ld;
    private List<String> sub_file_path;
    private long metadata_size = 0;
    public Metadata() {
        sub_file_path = new ArrayList<>();
    }

    public Metadata(String file_name) {
        this.file_name = file_name;
        sub_file_path = new ArrayList<>();
    }

    public long getMetadata_size() {
        return metadata_size;
    }

    public void setMetadata_size(long metadata_size) {
        this.metadata_size = metadata_size;
    }

    public void add(String data){
        // this.sub_file_path.add(file_path);
        this.metadata_size += data.length();
    }

    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }

    public LocalDate getLd() {
        return ld;
    }

    public void setLd(LocalDate ld) {
        this.ld = ld;
    }

    public List<String> getSub_file_path() {
        return sub_file_path;
    }

    public void setSub_file_path(List<String> sub_file_path) {
        this.sub_file_path = sub_file_path;
    }

    public int save(String metadata_path) {
        if(this.sub_file_path == null || this.sub_file_path.size() == 0){
            return -1;
        }
        File f = new File(metadata_path);

        try(BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(f), 4096)) {
            for (String s : this.sub_file_path) {
                bos.write(s.getBytes());
            }
            bos.flush();
        } catch (IOException e) {
            e.printStackTrace();
            return 0;
        }
        return 1;
    }
}
