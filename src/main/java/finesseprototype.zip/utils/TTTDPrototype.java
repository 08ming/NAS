package utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;


public class TTTDPrototype {

	Long p = 0L, l = 0L, backupBreak = 0L;//  p: current position      l: previous boundary position        backupBreak : boundary's swap space
	int sliding_window_size = 250;
	String current_for_rabin = "";
	InputStream io;
	Map<Integer, List<Long>> finesse_rs;//   12 features for finesse
	int Tmin = 512;
	private boolean optimized = false;
	int Tmax = 1024;
	int Ddash = 270, D = 540;
	int finesse_size = 12;
	public static TTTDPrototype instance;
	int chunk_count = 0;
	// int Tmin=943719;
	// int Tmax=1048576;
	// int Ddash=117964,D=235929;
	// TODO  record each chunk's rabin hash and serial number   day 2020/10/11
	RabinHashFunction rabinHashFunction = new RabinHashFunction();
	public Map<Integer, Chunk> breakpointlist; // contains each chunk's boundary   Integer: serial number      Long: boundary position
	String filepath;

	public boolean isOptimized() {
		return optimized;
	}

	public void setOptimized(boolean optimized) {
		this.optimized = optimized;
	}

	public void Init(String filepath) {
		this.p = 0L;
		this.l = 0L;
		this.backupBreak = 0L;
		this.filepath = filepath;
		this.breakpointlist = new HashMap<>();
		this.finesse_rs = new HashMap<>();
		this.chunk_count = 1;
	}

	public void init(String filepath, int sliding_windown_size, int Tmin, int Tmax, int Ddash, int D) {
		this.filepath = filepath;
		this.sliding_window_size = sliding_windown_size;
		this.Tmin = Tmin;
		this.Tmax = Tmax;
		this.Ddash = Ddash;
		this.D = D;
		breakpointlist = new HashMap<>();
		chunk_count = 0;
	}

	public void record_chunks_position() {
		try {
			breakpointlist.put(0,new Chunk(0L,0L,0L));
			long hashvalue = 0;
			io = new FileInputStream(new File(filepath));
			int c = -1;
			while ((c = io.read()) != -1) {
				p++;
				hashvalue = updateHash(c);
				if (p - l < Tmin) {// chunk_size = p -l  means that current size is less than Tmin
					continue;
				}
				if (((hashvalue % Ddash) == Ddash - 1) && (hashvalue != 0)) { // satisfy the condition of become a boundary     backupBreak : Boundary temporary storage area
					backupBreak = p;
				}
				if (hashvalue % D == D - 1) {// current hash value satisfy the condition , this position will be a boundary
					func(p, hashvalue);
					backupBreak = 0L;
					l = p;
					continue;
				}
				if (p - l < Tmax) {// current hash value doesn't  satisfy the condition and chunk size is less than Tmax
					continue;
				}
				if (backupBreak != 0) {// if current chunk size is greater than or equal to Tmax, record the position
					func(backupBreak,hashvalue);
					l = backupBreak;
					backupBreak = 0L;
				} else {// else the backupBreak is null，then the chunk size is Tmax
					func(p,hashvalue);
					l = p;
					backupBreak = 0L;
				}
			}
			if(!p.equals(backupBreak))
				func(p, hashvalue);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void func(Long p, Long hashvalue){
		Chunk pre_chunk = breakpointlist.get(	breakpointlist.size() -1 );
		Long offset = pre_chunk.offset + pre_chunk.size;
		Long size = p - offset;
		Chunk current_chunk = new Chunk(offset, hashvalue , size);
		addBreakpoint(current_chunk);
	}

	private void addBreakpoint(Chunk c) {
		breakpointlist.put(chunk_count,c);
		chunk_count ++;
	}

	private long updateHash(int c) {
		int current_size = current_for_rabin.length();
		if (current_size < sliding_window_size) {
			current_for_rabin += "" + c;
		} else {
			current_for_rabin = current_for_rabin.substring(current_size - sliding_window_size + 1);		// Otherwise the window slides to the right 1 byte
		}
		return rabinHashFunction.hash(current_for_rabin);
	}

	public Map<Integer, Chunk> getBreakpointlist() {
		breakpointlist.remove(0);
		return breakpointlist;
	}

}


