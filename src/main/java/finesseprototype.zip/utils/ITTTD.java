package utils;

/**
 * ClassName ITTTD
 * Description
 * Author Ka1HuangZhe
 * Date  10/23/2020
 */
public class ITTTD {
    public Metadata metadata;
}
